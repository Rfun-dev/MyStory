package com.example.mystory.data.respone

data class MessageResponse(
    val error : String,
    val message : String
)